package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

//imports
import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

//changed AppCompatActivity to Activity, meaning action bar features will not be used
public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //making the game full screen
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);

        setContentView(new GameView(this));
    }
}
